#ifndef _SIFRELEME_H
#define _SIFRELEME_H



void sifrele() ; 
void desifrele(); 
int menu(); 
void kaydirmaliSifreleme(); 


#endif

