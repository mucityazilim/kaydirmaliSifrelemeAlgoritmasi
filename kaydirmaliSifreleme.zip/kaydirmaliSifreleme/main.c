#include <stdio.h>
#include <stdlib.h>

#include "sifreleme.h"


// kayd�rmal� �ifreleme algoritmas� 
// mod�ler c yap�s� 
 

int main(int argc, char *argv[]) {
	
	kaydirmaliSifreleme(); 	
	
	return 0;
}
